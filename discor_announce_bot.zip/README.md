# discord_anounce_bot
 discord로 스터디 운영 시, 자동으로 공지를 해주는 프로그램
